 
const allconst = module.exports ={"serverpath":'http://localhost:3500/',"server_version_app":1};